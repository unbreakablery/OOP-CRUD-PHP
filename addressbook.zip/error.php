<?php include "inc/header.php"; ?>

<section id="content">
    <div class="container">
        <div class="col-12 mt-4 mb-4">
            <h2 class="font-weight-bolder text-danger">Sorry, Operation Error!</h2>
        </div>
        <div class="col-12">
            <a href="./index.php" class="btn btn-secondary">Back</a>
        </div>
    </div>
</section>

<?php include "inc/footer.php"; ?>